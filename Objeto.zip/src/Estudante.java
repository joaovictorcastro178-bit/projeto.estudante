

public class Estudante {

    private String nome;
    private int idade;
    private int matricula;
    private String endereco;
    
public void estuda (){
    System.out.println(nome+" está estudando!");
    
}
public void sofrer () {
    System.out.println(nome+" quer tomar um undaia!");
}  

public void realizaProva () {
    System.out.println(nome+" está realizando a prova!");
} 

public void realizaAtividade () {
    System.out.println(nome+" está realizando uma atividade!");
}      

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Estudante(String nome, int idade, int matricula, String endereco) {
        this.nome = nome;
        this.idade = idade;
        this.matricula = matricula;
        this.endereco = endereco;
    }
    
}
