

public class OrientadaObjeto {
    public static void main(String[] args) {
        Estudante aluno = new Estudante("Felg", 23, 123456, "Rua n° 13 ");
        System.out.println("\n"+aluno.getNome()+"\n"+aluno.getEndereco()+"\n"+aluno.getIdade()+"\n"+aluno.getMatricula());
        
        aluno.sofrer();
        
       
       
    }

    
}
